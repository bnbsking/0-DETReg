#!/bin/bash

mode_arr=(finetune finetune_resume evalutation visualization)
MODE_IDX=0
OUTPUT_DIR="_exps/downstream/xavier_60k_ep154_labv3/"
FINETUNE_WEIGHT="_exps/pretext/xavier_60k/checkpoint.pth"
#FINETUNE_WEIGHT="_exps/downstream/coco_40k_ep200_c70620/checkpoint.pth"
LR_DROP=999
EPOCHS=130
DATA_ROOT_FT="_data/downstream/labv3"

if [ $MODE_IDX == 0 ]; then
    python -u main.py --output_dir $OUTPUT_DIR --dataset coco --pretrain $FINETUNE_WEIGHT --batch_size 4 --num_workers 8 --data_root_ft $DATA_ROOT_FT --epochs $EPOCHS --lr_drop $LR_DROP 

elif [ $MODE_IDX == 1 ]; then
    python -u main.py --output_dir $OUTPUT_DIR --dataset coco --pretrain $FINETUNE_WEIGHT --batch_size 4 --num_workers 8 --data_root_ft $DATA_ROOT_FT --resume $FINETUNE_WEIGHT --epochs $EPOCHS --lr_drop $LR_DROP

elif [ $MODE_IDX == 2 ]; then
    python -u main.py --output_dir $OUTPUT_DIR --dataset coco --pretrain $FINETUNE_WEIGHT --batch_size 4 --num_workers 8 --data_root_ft $DATA_ROOT_FT --resume $FINETUNE_WEIGHT --eval
    
else
    python -u main.py --output_dir $OUTPUT_DIR --dataset coco --pretrain $FINETUNE_WEIGHT --batch_size 1 --num_workers 8 --data_root_ft $DATA_ROOT_FT --resume $FINETUNE_WEIGHT --viz
    
fi